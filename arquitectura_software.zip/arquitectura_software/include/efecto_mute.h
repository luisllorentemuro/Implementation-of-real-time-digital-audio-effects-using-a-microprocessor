/** \file efecto_mute.h
* A brief file description.
* Created on:    2022/07/13
* Last modified: 2022/07/13 09:49:36
*/

#ifndef _EFECTO_MUTE_H_
#define _EFECTO_MUTE_H_

// Este efecto no tiene parámetros de configuración

#endif  /* _EFECTO_MUTE_H_ */ 
