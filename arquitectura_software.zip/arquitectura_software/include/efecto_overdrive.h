/** \file efecto_overdrive.h
* A brief file description.
* Created on:    2022/07/13
* Last modified: 2022/07/13 09:44:03
*/

#ifndef _EFECTO_OVERDRIVE_H_
#define _EFECTO_OVERDRIVE_H_
/******************************************************************************
* Includes
*******************************************************************************/
#include <stdint.h>
#include <math.h>
/******************************************************************************
* Module Typedefs
*******************************************************************************/

// Este efecto no tiene parámetros de configuración

#endif  /* _EFECTO_OVERDRIVE_H_ */ 
