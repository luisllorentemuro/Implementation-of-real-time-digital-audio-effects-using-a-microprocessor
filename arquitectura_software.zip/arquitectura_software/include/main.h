/*
 * lab.h

 */

#include <stdint.h>
#ifndef _lab6_H_
#define _lab6_H_

#define IncPh_1300 1775
#define IncPh_2100 2867



#define LOOPBACK_I2S 0 //loopback [1 activo]

int16_t contador_g;

#endif /* CONSTANTS_lab6_H_ */